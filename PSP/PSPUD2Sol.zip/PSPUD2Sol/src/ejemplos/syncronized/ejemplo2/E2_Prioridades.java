package ejemplos.syncronized.ejemplo2;

public class E2_Prioridades {
    public static void main(String[] args) {
        System.out.println("Prioridades de hilos en Java:");
        System.out.println("Mínima: " + Thread.MIN_PRIORITY);
        System.out.println("Normal (por defecto): " + Thread.NORM_PRIORITY);
        System.out.println("Máxima: " + Thread.MAX_PRIORITY);
    }
}
