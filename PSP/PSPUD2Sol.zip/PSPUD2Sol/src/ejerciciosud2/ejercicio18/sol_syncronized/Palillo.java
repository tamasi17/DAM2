package ejerciciosud2.ejercicio18.sol_syncronized;

/*  @author:   */

public class Palillo {

	private int numeroPalillo;

	public Palillo(int palillo) {
		this.numeroPalillo =palillo;
	}

	public int getNumeroPalillo() {
		return numeroPalillo;
	}

	public void setNumeroPalillo(int numeroPalillo) {
		this.numeroPalillo = numeroPalillo;
	}







}
