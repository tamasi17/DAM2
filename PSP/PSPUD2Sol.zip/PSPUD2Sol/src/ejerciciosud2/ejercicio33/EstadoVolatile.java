package ejerciciosud2.ejercicio33;

public class EstadoVolatile {
    boolean activo = false; // garantiza visibilidad entre hilos
}
