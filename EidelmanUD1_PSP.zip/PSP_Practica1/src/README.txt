

PRACTICA UT1
Mati Eidelman

Seguimiento Simulador Malware:

    En primer lugar hice todo el proceso en el main.
    Como quedaba muy cargado lo he puesto por separado en una clase SimuladorMalware.
    Aún no estoy acostumbrado a poner los metodos en el mismo archivo como se hace en el turno de tarde.

    No tengo Firefox, he puesto opciones para Chrome o Internet Explorer (comentando/descomentando)

    El número de bucles que se repite el malware se puede cambiar en la clase SimuladorMalware.

    No he conseguido matar el proceso con PIDs
    El ProcessBuilder para matarProceso(nombreProceso) es de David Palacios.

    apagar() no apaga, se puede lanzar sin miedo.

    He usado ChatGPT sobre todo para matarProceso(), sin éxito.


